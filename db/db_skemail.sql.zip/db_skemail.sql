-- phpMyAdmin SQL Dump
-- version 2.10.3
-- http://www.phpmyadmin.net
-- 
-- โฮสต์: localhost
-- เวลาในการสร้าง: 
-- รุ่นของเซิร์ฟเวอร์: 5.0.51
-- รุ่นของ PHP: 5.2.6

SET SQL_MODE="NO_AUTO_VALUE_ON_ZERO";

-- 
-- ฐานข้อมูล: `db_alram`
-- 

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `db_log_error`
-- 

CREATE TABLE `db_log_error` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `name_er` text NOT NULL,
  `time` text NOT NULL,
  `clear_log` text NOT NULL,
  `num_er` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2631 ;

-- 
-- dump ตาราง `db_log_error`
-- 

INSERT INTO `db_log_error` VALUES (2630, 1, 'AL5 Phase error ', '12/02/2018  12:25:07am', '111111', 5);
INSERT INTO `db_log_error` VALUES (2629, 1, 'AL3 Blower overload ', '12/02/2018  12:24:09am', '28/07/2561 23:50:53', 3);
INSERT INTO `db_log_error` VALUES (2628, 1, 'AL2 Door open ', '12/02/2018  12:21:01am', '29/07/2561 00:01:04', 2);
INSERT INTO `db_log_error` VALUES (2627, 1, 'AL2 Door open ', '12/02/2018  12:15:19am', '', 2);
INSERT INTO `db_log_error` VALUES (2626, 1, 'AL2 Door open ', '12/02/2018  12:14:15am', '28/07/2561 23:02:31', 2);
INSERT INTO `db_log_error` VALUES (2625, 1, 'AL2 Door open ', '12/02/2018  12:12:41am', '28/07/2561 23:51:15', 2);
INSERT INTO `db_log_error` VALUES (2605, 5, '1 ', '27/10/2017  09:50:01am', '', 1);
INSERT INTO `db_log_error` VALUES (2606, 5, '6 ', '27/10/2017  09:50:25am', '', 6);
INSERT INTO `db_log_error` VALUES (2607, 5, '11  ', '27/10/2017  09:51:03am', '', 11);
INSERT INTO `db_log_error` VALUES (2608, 5, '14 ', '27/10/2017  09:51:16am', '', 14);
INSERT INTO `db_log_error` VALUES (2609, 4, '3 ', '27/10/2017  09:58:14am', '', 3);
INSERT INTO `db_log_error` VALUES (2610, 4, '8 ', '27/10/2017  09:58:34am', '', 8);
INSERT INTO `db_log_error` VALUES (2611, 4, '12 ', '27/10/2017  09:58:59am', '', 12);
INSERT INTO `db_log_error` VALUES (2612, 4, '15 ', '27/10/2017  09:59:13am', '', 15);
INSERT INTO `db_log_error` VALUES (2613, 6, '13 ', '27/10/2017  10:14:12am', '', 13);
INSERT INTO `db_log_error` VALUES (2614, 6, '10 ', '27/10/2017  10:14:27am', '', 10);
INSERT INTO `db_log_error` VALUES (2615, 6, '8 ', '27/10/2017  10:14:45am', '', 8);
INSERT INTO `db_log_error` VALUES (2616, 6, '3 ', '27/10/2017  10:14:59am', '', 3);
INSERT INTO `db_log_error` VALUES (2617, 7, '1 ', '27/10/2017  10:18:53am', '', 1);
INSERT INTO `db_log_error` VALUES (2618, 7, '4 ', '27/10/2017  10:19:16am', '', 4);
INSERT INTO `db_log_error` VALUES (2619, 7, '9 ', '27/10/2017  10:19:39am', '', 9);
INSERT INTO `db_log_error` VALUES (2620, 7, '15 ', '27/10/2017  10:20:00am', '', 15);
INSERT INTO `db_log_error` VALUES (2621, 8, '2 ', '27/10/2017  10:23:34am', '', 2);
INSERT INTO `db_log_error` VALUES (2622, 8, '6 ', '27/10/2017  10:24:01am', '', 6);
INSERT INTO `db_log_error` VALUES (2623, 8, '11 ', '27/10/2017  10:24:27am', '', 11);
INSERT INTO `db_log_error` VALUES (2624, 8, '12 ', '27/10/2017  10:24:44am', '', 12);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_alm_log`
-- 

CREATE TABLE `tb_alm_log` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `alm` int(11) NOT NULL,
  `days` text NOT NULL,
  `stu` int(11) NOT NULL,
  `count` int(11) NOT NULL,
  `email` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=tis620 AUTO_INCREMENT=7 ;

-- 
-- dump ตาราง `tb_alm_log`
-- 

INSERT INTO `tb_alm_log` VALUES (1, 5, 1, '19/04/2018', 0, 0, 0);
INSERT INTO `tb_alm_log` VALUES (3, 3, 0, '04/04/2018', 1, 0, 0);
INSERT INTO `tb_alm_log` VALUES (4, 7, 1, '0', 0, 0, 0);
INSERT INTO `tb_alm_log` VALUES (5, 6, 1, '0', 0, 0, 0);
INSERT INTO `tb_alm_log` VALUES (6, 1, 1, '0', 0, 0, 0);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_countsend`
-- 

CREATE TABLE `tb_countsend` (
  `id` int(11) NOT NULL auto_increment,
  `send` int(11) NOT NULL,
  `date` text NOT NULL,
  `num` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `tb_countsend`
-- 

INSERT INTO `tb_countsend` VALUES (1, 0, '30/07/2018', 1);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_email`
-- 

CREATE TABLE `tb_email` (
  `id` int(11) NOT NULL auto_increment,
  `mail1` text NOT NULL,
  `mail2` text NOT NULL,
  `mail3` text NOT NULL,
  `mail4` text NOT NULL,
  `mail5` text NOT NULL,
  `mail6` text NOT NULL,
  `mail7` text NOT NULL,
  `mail8` text NOT NULL,
  `mail9` text NOT NULL,
  `mail10` text NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- dump ตาราง `tb_email`
-- 

INSERT INTO `tb_email` VALUES (1, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 1);
INSERT INTO `tb_email` VALUES (2, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 3);
INSERT INTO `tb_email` VALUES (3, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', 'Pisit@qminvent.com', 'Chaiyasit@qminvent.com', 'Panuwat@qminvent.com', 'Montri@qminvent.com', 'Ray5218247@gmail.com', 4);
INSERT INTO `tb_email` VALUES (4, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 5);
INSERT INTO `tb_email` VALUES (5, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 6);
INSERT INTO `tb_email` VALUES (6, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 7);
INSERT INTO `tb_email` VALUES (7, 'skservice@sksynergy.com', 'atichart@sksynergy.com', 'jamnong@sksynergy.com', 'service@sksynergy.com', 'qc3@sksynergy.com', '', '', '', '', '', 8);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_emailsend`
-- 

CREATE TABLE `tb_emailsend` (
  `id` int(11) NOT NULL auto_increment,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- dump ตาราง `tb_emailsend`
-- 

INSERT INTO `tb_emailsend` VALUES (1, 'iras@synergywebmonitor.com', 'mUBbiv71f');
INSERT INTO `tb_emailsend` VALUES (2, 'iras1@synergywebmonitor.com', 'mUBbiv71f');
INSERT INTO `tb_emailsend` VALUES (3, 'iras2@synergywebmonitor.com', 'mUBbiv71f');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_led_show`
-- 

CREATE TABLE `tb_led_show` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `msg1` varchar(60) NOT NULL,
  `msg2` varchar(60) NOT NULL,
  `msg3` varchar(60) NOT NULL,
  `msg4` varchar(60) NOT NULL,
  `msg5` varchar(60) NOT NULL,
  `msg6` varchar(60) NOT NULL,
  `msg7` varchar(60) NOT NULL,
  `msg8` varchar(60) NOT NULL,
  `msg9` varchar(60) NOT NULL,
  `msg10` varchar(60) NOT NULL,
  `msg_group` varchar(10) NOT NULL,
  `data_group` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=7 ;

-- 
-- dump ตาราง `tb_led_show`
-- 

INSERT INTO `tb_led_show` VALUES (6, 5, 'R', 'R', 'R', 'Y', 'Y', 'Y', 'Y', 'R', '', '', 'ALARM', 14);
INSERT INTO `tb_led_show` VALUES (4, 5, 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', 'Y', '', '', 'INPUT', 1);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_log_show`
-- 

CREATE TABLE `tb_log_show` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `log` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=4 ;

-- 
-- dump ตาราง `tb_log_show`
-- 

INSERT INTO `tb_log_show` VALUES (1, 0, 1);
INSERT INTO `tb_log_show` VALUES (2, 1, 1);
INSERT INTO `tb_log_show` VALUES (3, 5, 1);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_machine`
-- 

CREATE TABLE `tb_machine` (
  `id` int(11) NOT NULL auto_increment,
  `name` text NOT NULL,
  `mac_no` text NOT NULL,
  `location` text NOT NULL,
  `id_user` int(11) NOT NULL,
  `web` int(11) NOT NULL,
  `model` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=15 ;

-- 
-- dump ตาราง `tb_machine`
-- 

INSERT INTO `tb_machine` VALUES (1, 'WPLC2.0-AIR', 'SK17xxxxx', 'CPRAM LATLUMKAEO', 1, 1, 'xxxxx');
INSERT INTO `tb_machine` VALUES (2, 'ID5', '', '', 5, 1, '');
INSERT INTO `tb_machine` VALUES (3, 'ID6', '', '', 6, 1, '');
INSERT INTO `tb_machine` VALUES (4, 'ID7', '', '', 7, 1, '');
INSERT INTO `tb_machine` VALUES (5, 'ID8', '', '', 8, 0, '');
INSERT INTO `tb_machine` VALUES (6, '111', '1111', '1111', 9, 0, '');
INSERT INTO `tb_machine` VALUES (13, 'GGGGGG', '333', '3444444', 11, 0, '');
INSERT INTO `tb_machine` VALUES (12, '2222', '3333', '4444', 10, 0, '');
INSERT INTO `tb_machine` VALUES (14, '1111', '1111', '1111', 12, 0, '1111');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_mail`
-- 

CREATE TABLE `tb_mail` (
  `id` int(11) NOT NULL auto_increment,
  `msg1` text NOT NULL,
  `msg2` text NOT NULL,
  `msg3` text NOT NULL,
  `msg4` text NOT NULL,
  `msg5` text NOT NULL,
  `msg6` text NOT NULL,
  `msg7` text NOT NULL,
  `msg8` text NOT NULL,
  `msg9` text NOT NULL,
  `msg10` text NOT NULL,
  `msg11` text NOT NULL,
  `msg12` text NOT NULL,
  `msg13` text NOT NULL,
  `msg14` text NOT NULL,
  `msg15` text NOT NULL,
  `msg16` text NOT NULL,
  `id_user` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=8 ;

-- 
-- dump ตาราง `tb_mail`
-- 

INSERT INTO `tb_mail` VALUES (1, '', 'AL2 Door open', 'AL3 Blower overload', 'AL4 Emergency stop', 'AL5 Phase error', 'AL6 Pump cooling overload', '', '', '', '', '', '', '', '', '', '', 1);
INSERT INTO `tb_mail` VALUES (2, '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', 3);
INSERT INTO `tb_mail` VALUES (5, '', '', '3', '', '', '', '', '8', '', '10', '', '', '13', '', '', '', 6);
INSERT INTO `tb_mail` VALUES (6, '1', '', '', '4', '', '', '', '', '9', '', '', '', '', '', '15', '', 7);
INSERT INTO `tb_mail` VALUES (3, 'Alarm1 Pump overload', 'Alarm2 Run dry', 'Alarm3 Door open', 'Alarm4 Air pressure in', '', '', '', '', '', '', '', '', '', '', '', '', 4);
INSERT INTO `tb_mail` VALUES (4, '1', '', '', '', '', '6', '', '', '', '', '11 ', '', '', '14', '', '', 5);
INSERT INTO `tb_mail` VALUES (7, '', '2', '', '', '', '6', '', '', '', '', '11', '12', '', '', '', '', 8);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_monitor`
-- 

CREATE TABLE `tb_monitor` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `time` text NOT NULL,
  `pump` text NOT NULL,
  `air` text NOT NULL,
  `loadcell` text NOT NULL,
  `fan` text NOT NULL,
  `sol1` text NOT NULL,
  `sol2` text NOT NULL,
  `autob` text NOT NULL,
  `autosv` text NOT NULL,
  `time_on` text NOT NULL,
  `time_off` text NOT NULL,
  `pumpo` text NOT NULL,
  `air_o` text NOT NULL,
  `run_dry` text NOT NULL,
  `mode` text NOT NULL,
  `ana_c1` text NOT NULL,
  `ana_c2` text NOT NULL,
  `ana_c3` text NOT NULL,
  `ana_c4` text NOT NULL,
  `ana_c5` text NOT NULL,
  `ana_c6` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `tb_monitor`
-- 

INSERT INTO `tb_monitor` VALUES (1, 3, '04/11/2017  11:19:09am', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_monitor_a`
-- 

CREATE TABLE `tb_monitor_a` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `data_log` text NOT NULL,
  `pump` text NOT NULL,
  `air_com` text NOT NULL,
  `load_cell` text NOT NULL,
  `fan` text NOT NULL,
  `valve1` text NOT NULL,
  `valve2` text NOT NULL,
  `auto_bleed` text NOT NULL,
  `auto_bleedoff` text NOT NULL,
  `pump_over` text NOT NULL,
  `air_com_over` text NOT NULL,
  `run_dry1` text NOT NULL,
  `mode_r` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=6 ;

-- 
-- dump ตาราง `tb_monitor_a`
-- 

INSERT INTO `tb_monitor_a` VALUES (1, 1, '111', '1', '1', '1', '1', '', '', '', '', '', '', '', '2');
INSERT INTO `tb_monitor_a` VALUES (2, 1, '21/11/2017  11:19:45am', 'FF', '1H', '', '', '', '', '', '', '', '', '', '');
INSERT INTO `tb_monitor_a` VALUES (3, 1, '21/11/2017  11:22:00am', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `tb_monitor_a` VALUES (4, 1, '21/11/2017  11:22:36am', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0', '0');
INSERT INTO `tb_monitor_a` VALUES (5, 1, '21/11/2017  11:24:16am', '255', '1', '34', '0', '0', '0', '0', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_monitor_b`
-- 

CREATE TABLE `tb_monitor_b` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `data_log` text NOT NULL,
  `timeon` text NOT NULL,
  `timeoff` text NOT NULL,
  `delay_time` text NOT NULL,
  `d2` text NOT NULL,
  `analog1` text NOT NULL,
  `analog2` text NOT NULL,
  `analog3` text NOT NULL,
  `analog4` text NOT NULL,
  `analog5` text NOT NULL,
  `analog6` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- dump ตาราง `tb_monitor_b`
-- 

INSERT INTO `tb_monitor_b` VALUES (14, 0, '02/12/2017  09:31:50am', ',01,0,0', '', '', '', '', '', '', '', '', '');
INSERT INTO `tb_monitor_b` VALUES (15, 3, '02/12/2017  09:33:24am', ',01,0,0', '', '', '', '', '', '', '', '', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_monitor_c`
-- 

CREATE TABLE `tb_monitor_c` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `data_log` text NOT NULL,
  `input1` text NOT NULL,
  `input2` text NOT NULL,
  `input3` text NOT NULL,
  `output1` text NOT NULL,
  `output2` text NOT NULL,
  `output3` text NOT NULL,
  `alram1` text NOT NULL,
  `alram2` text NOT NULL,
  `alram3` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- dump ตาราง `tb_monitor_c`
-- 

INSERT INTO `tb_monitor_c` VALUES (1, 1, '', '20', '100', '30', '11', '22', '33', '44', '55', '66');
INSERT INTO `tb_monitor_c` VALUES (2, 1, '21/11/2017  11:41:37am', '200', '340', '2', '10', '10.3', '22.4', '', '', '');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_monitor_st`
-- 

CREATE TABLE `tb_monitor_st` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `pump` int(11) NOT NULL,
  `air` int(11) NOT NULL,
  `loadcell` int(11) NOT NULL,
  `fan` int(11) NOT NULL,
  `sol1` int(11) NOT NULL,
  `sol2` int(11) NOT NULL,
  `autob` int(11) NOT NULL,
  `autosv` int(11) NOT NULL,
  `time_on` int(11) NOT NULL,
  `time_off` int(11) NOT NULL,
  `pumpo` int(11) NOT NULL,
  `air_o` int(11) NOT NULL,
  `run_dry` int(11) NOT NULL,
  `mode` int(11) NOT NULL,
  `ana_c1` int(11) NOT NULL,
  `ana_c2` int(11) NOT NULL,
  `ana_c3` int(11) NOT NULL,
  `ana_c4` int(11) NOT NULL,
  `ana_c5` int(11) NOT NULL,
  `ana_c6` int(11) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `tb_monitor_st`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_msg_a`
-- 

CREATE TABLE `tb_msg_a` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- dump ตาราง `tb_msg_a`
-- 

INSERT INTO `tb_msg_a` VALUES (1, '1', ',12,0,0,0,0,0,12,0,0,0,0,0');
INSERT INTO `tb_msg_a` VALUES (2, '', ',01,0,0,0,0,0,95,0,0,0,0,0');
INSERT INTO `tb_msg_a` VALUES (3, '', ',01,0,0,0,0,0,95,0,0,0,0,0');
INSERT INTO `tb_msg_a` VALUES (4, '', ',01,0,0,0,0,0,95,0,0,0,0,0');
INSERT INTO `tb_msg_a` VALUES (5, '', ',01,0,0,0,0,0,95,0,0,0,0,255');
INSERT INTO `tb_msg_a` VALUES (6, '', ',01,0,0,0,0,0,95,95,0,0,0,255');
INSERT INTO `tb_msg_a` VALUES (7, '', ',01,95,95,95,95,95,95,95,95,95,95,255');
INSERT INTO `tb_msg_a` VALUES (8, '', ',01,95,95,95,95,95,95,95,95,95,95,255');
INSERT INTO `tb_msg_a` VALUES (9, '', ',01,95,95,95,95,95,95,95,95,95,95,255');
INSERT INTO `tb_msg_a` VALUES (10, '', ',01,95,95,95,95,95,95,95,95,95,95,255');
INSERT INTO `tb_msg_a` VALUES (11, '5', ',01,95,95,95,95,95,95,95,95,95,95,255');
INSERT INTO `tb_msg_a` VALUES (12, '5', ',01,95,95,95,95,95,95,95,95,95,95,255');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_msg_b`
-- 

CREATE TABLE `tb_msg_b` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `tb_msg_b`
-- 

INSERT INTO `tb_msg_b` VALUES (1, '1', '12,0,0');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_msg_c`
-- 

CREATE TABLE `tb_msg_c` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` text NOT NULL,
  `msg` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=2 ;

-- 
-- dump ตาราง `tb_msg_c`
-- 

INSERT INTO `tb_msg_c` VALUES (1, '1', ',12,0,0');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_msg_show`
-- 

CREATE TABLE `tb_msg_show` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `msg1` varchar(60) NOT NULL,
  `msg2` varchar(60) NOT NULL,
  `msg3` varchar(60) NOT NULL,
  `msg4` varchar(60) NOT NULL,
  `msg5` varchar(60) NOT NULL,
  `msg6` varchar(60) NOT NULL,
  `msg7` varchar(60) NOT NULL,
  `msg8` varchar(60) NOT NULL,
  `msg9` varchar(60) NOT NULL,
  `msg10` varchar(60) NOT NULL,
  `msg_group` varchar(10) NOT NULL,
  `data_group` int(1) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=16 ;

-- 
-- dump ตาราง `tb_msg_show`
-- 

INSERT INTO `tb_msg_show` VALUES (1, 1, 'Test', 'ทดสอบการทำงาน', 'ABCD', '', '', '', '', '', '', '', 'INPUT', 12);
INSERT INTO `tb_msg_show` VALUES (9, 5, 'dada', '', '', 'dada', '', 'dddd', 'dddd', 'ddd', '', '', 'INPUT', 13);
INSERT INTO `tb_msg_show` VALUES (6, 1, 'PUMP', 'PUMP', 'PUMP', 'PUMP', 'PUMP', 'PUMP', 'PUMP', 'PUMP', '', '', 'INPUT', 1);
INSERT INTO `tb_msg_show` VALUES (7, 1, 'T1', 'T2', 'T3', 'T1', 'T5', 'T6', 'T7', 'T8', '', '', 'ALARM', 14);
INSERT INTO `tb_msg_show` VALUES (8, 1, 'TIME ON', 'TIME OFF', 'D1', 'D2', 'A', 'B', 'C', 'D', 'E', 'F', 'OUTPUT', 13);
INSERT INTO `tb_msg_show` VALUES (10, 1, 'Test', 'test', '', '', '', '', '', '', '', '', 'OUTPUT', 2);
INSERT INTO `tb_msg_show` VALUES (11, 6, 'test', '', '', '', '', '', '', '', '', '', 'INPUT', 1);
INSERT INTO `tb_msg_show` VALUES (12, 7, '222', '', '', '', '', '', '', '', '', '', 'INPUT', 13);
INSERT INTO `tb_msg_show` VALUES (13, 5, '1', '2', '3', '4', '5', '6', '7', '8', '', '', 'OUTPUT', 7);
INSERT INTO `tb_msg_show` VALUES (14, 5, '1', '2', '3', '4', '5', '6', '7', '8', '', '', 'INPUT', 1);
INSERT INTO `tb_msg_show` VALUES (15, 5, '111', '111', '111', '111', '111', '11', '111', '111', '', '', 'ALARM', 14);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_s_connect`
-- 

CREATE TABLE `tb_s_connect` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `id_log` int(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=3 ;

-- 
-- dump ตาราง `tb_s_connect`
-- 

INSERT INTO `tb_s_connect` VALUES (1, 1, 0);
INSERT INTO `tb_s_connect` VALUES (2, 5, 0);

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_user`
-- 

CREATE TABLE `tb_user` (
  `id_user` int(11) NOT NULL auto_increment,
  `user` text NOT NULL,
  `pass` text NOT NULL,
  `encap` text NOT NULL,
  PRIMARY KEY  (`id_user`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=13 ;

-- 
-- dump ตาราง `tb_user`
-- 

INSERT INTO `tb_user` VALUES (1, 'test1', 'test', 'user');
INSERT INTO `tb_user` VALUES (2, 'admin', 'sk123456', 'admin');
INSERT INTO `tb_user` VALUES (3, 'CUSTOMER3', 'SYNERGY3', 'user');
INSERT INTO `tb_user` VALUES (4, 'CUSTOMER4', 'SYNERGY4', 'user');
INSERT INTO `tb_user` VALUES (5, 'CUSTOMER5', 'SYNERGY5', 'user');
INSERT INTO `tb_user` VALUES (6, 'CUSTOMER6', 'SYNERGY6', 'user');
INSERT INTO `tb_user` VALUES (7, 'CUSTOMER7', 'SYNERGY7', 'user');
INSERT INTO `tb_user` VALUES (8, 'CUSTOMER8', 'SYNERGY8', 'user');
INSERT INTO `tb_user` VALUES (9, '111', '1234', 'user');
INSERT INTO `tb_user` VALUES (10, '3333', '44444', 'user');
INSERT INTO `tb_user` VALUES (11, '111222', '33333', 'user');
INSERT INTO `tb_user` VALUES (12, '222', '2222', 'user');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_user_log`
-- 

CREATE TABLE `tb_user_log` (
  `id` int(11) NOT NULL auto_increment,
  `id_user` int(11) NOT NULL,
  `pic` text NOT NULL,
  `time_login` text NOT NULL,
  `time_logout` text NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8 AUTO_INCREMENT=1 ;

-- 
-- dump ตาราง `tb_user_log`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_web_monitor_a`
-- 

CREATE TABLE `tb_web_monitor_a` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `date_log` text NOT NULL,
  `input1` varchar(8) NOT NULL,
  `input2` varchar(8) NOT NULL,
  `input3` varchar(8) NOT NULL,
  `input4` varchar(8) NOT NULL,
  `input5` varchar(8) NOT NULL,
  `input6` varchar(8) NOT NULL,
  `output1` varchar(8) NOT NULL,
  `output2` varchar(8) NOT NULL,
  `output3` varchar(8) NOT NULL,
  `output4` varchar(8) NOT NULL,
  `output5` varchar(8) NOT NULL,
  `output6` varchar(8) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=58 ;

-- 
-- dump ตาราง `tb_web_monitor_a`
-- 

INSERT INTO `tb_web_monitor_a` VALUES (56, 5, '08/02/2018  11:09:14am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (57, 5, '08/02/2018  11:26:56am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (55, 0, '08/02/2018  11:08:58am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (54, 0, '08/02/2018  11:07:05am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (53, 0, '08/02/2018  11:06:56am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (52, 0, '08/02/2018  11:06:46am', '1', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '1011111', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (51, 0, '08/02/2018  11:06:19am', '1', '0', '0', '0', '0', '0', '1011111', '1011111', '0', '0', '0', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (49, 0, '08/02/2018  11:02:05am', '1', '0', '0', '0', '0', '0', '1011111', '0', '0', '0', '0', '0');
INSERT INTO `tb_web_monitor_a` VALUES (50, 0, '08/02/2018  11:02:20am', '1', '0', '0', '0', '0', '0', '1011111', '0', '0', '0', '0', '11111111');
INSERT INTO `tb_web_monitor_a` VALUES (47, 0, '08/02/2018  11:00:51am', '1', '0', '0', '0', '0', '0', '1011111', '0', '0', '0', '0', '0');
INSERT INTO `tb_web_monitor_a` VALUES (48, 0, '08/02/2018  11:01:30am', '1', '0', '0', '0', '0', '0', '1011111', '0', '0', '0', '0', '0');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_web_monitor_b`
-- 

CREATE TABLE `tb_web_monitor_b` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `date_log` text NOT NULL,
  `time_on` varchar(10) NOT NULL,
  `time_off` varchar(10) NOT NULL,
  `d1` varchar(10) NOT NULL,
  `d2` varchar(10) NOT NULL,
  `ch1` varchar(10) NOT NULL,
  `ch2` varchar(10) NOT NULL,
  `ch3` varchar(10) NOT NULL,
  `ch4` varchar(10) NOT NULL,
  `ch5` varchar(10) NOT NULL,
  `ch6` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=521 ;

-- 
-- dump ตาราง `tb_web_monitor_b`
-- 

INSERT INTO `tb_web_monitor_b` VALUES (520, 3, '13/12/2017  05:26:15pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (519, 3, '13/12/2017  05:26:07pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (518, 3, '13/12/2017  05:25:59pm', '0713', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (517, 3, '13/12/2017  05:25:51pm', '0705', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (516, 3, '13/12/2017  05:25:43pm', '0697', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (515, 3, '13/12/2017  05:25:35pm', '0689', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (514, 3, '13/12/2017  05:25:27pm', '0681', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (513, 3, '13/12/2017  05:25:19pm', '0673', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (512, 3, '13/12/2017  05:25:11pm', '0665', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (511, 3, '13/12/2017  05:25:03pm', '0657', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (510, 3, '13/12/2017  05:24:55pm', '0649', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (509, 3, '13/12/2017  05:24:47pm', '0641', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (508, 3, '13/12/2017  05:24:39pm', '0633', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (507, 3, '13/12/2017  05:24:31pm', '0625', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (506, 3, '13/12/2017  05:24:23pm', '0617', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (505, 3, '13/12/2017  05:24:15pm', '0609', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (504, 3, '13/12/2017  05:24:07pm', '0601', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (503, 3, '13/12/2017  05:23:59pm', '0593', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (502, 3, '13/12/2017  05:23:52pm', '0585', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (501, 3, '13/12/2017  05:23:44pm', '0577', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (500, 3, '13/12/2017  05:23:36pm', '0569', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (499, 3, '13/12/2017  05:23:28pm', '0561', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (498, 3, '13/12/2017  05:23:20pm', '0553', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (497, 3, '13/12/2017  05:23:12pm', '0546', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (496, 3, '13/12/2017  05:23:04pm', '0538', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (495, 3, '13/12/2017  05:22:56pm', '0529', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (494, 3, '13/12/2017  05:22:48pm', '0521', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (493, 3, '13/12/2017  05:22:39pm', '0512', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (492, 3, '13/12/2017  05:22:31pm', '0504', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (491, 3, '13/12/2017  05:22:22pm', '0496', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (490, 3, '13/12/2017  05:22:14pm', '0488', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (489, 3, '13/12/2017  05:22:06pm', '0480', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (488, 3, '13/12/2017  05:21:58pm', '0472', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (487, 3, '13/12/2017  05:21:50pm', '0464', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (486, 3, '13/12/2017  05:21:43pm', '0455', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (485, 3, '13/12/2017  05:21:34pm', '0447', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (484, 3, '13/12/2017  05:21:26pm', '0439', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (483, 3, '13/12/2017  05:21:18pm', '0431', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (482, 3, '13/12/2017  05:21:10pm', '0423', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (481, 3, '13/12/2017  05:21:01pm', '0415', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (480, 3, '13/12/2017  05:20:53pm', '0407', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (479, 3, '13/12/2017  05:20:45pm', '0399', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (478, 3, '13/12/2017  05:20:37pm', '0391', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (477, 3, '13/12/2017  05:20:29pm', '0382', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (476, 3, '13/12/2017  05:20:20pm', '0374', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (475, 3, '13/12/2017  05:20:12pm', '0366', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (474, 3, '13/12/2017  05:20:04pm', '0358', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (473, 3, '13/12/2017  05:19:54pm', '0348', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (472, 3, '13/12/2017  05:19:46pm', '0340', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (471, 3, '13/12/2017  05:19:38pm', '0332', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (470, 3, '13/12/2017  05:19:30pm', '0323', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (469, 3, '13/12/2017  05:19:21pm', '0315', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (468, 3, '13/12/2017  05:19:13pm', '0306', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (467, 3, '13/12/2017  05:19:04pm', '0298', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (466, 3, '13/12/2017  05:18:56pm', '0289', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (465, 3, '13/12/2017  05:18:47pm', '0281', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (464, 3, '13/12/2017  05:18:39pm', '0273', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (463, 3, '13/12/2017  05:18:31pm', '0265', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (462, 3, '13/12/2017  05:18:23pm', '0257', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.93', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (461, 3, '13/12/2017  05:18:15pm', '0249', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (460, 3, '13/12/2017  05:18:07pm', '0241', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (459, 3, '13/12/2017  05:17:59pm', '0233', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (458, 3, '13/12/2017  05:17:51pm', '0225', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (457, 3, '13/12/2017  05:17:43pm', '0217', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (456, 3, '13/12/2017  05:17:35pm', '0209', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.94', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (455, 3, '13/12/2017  05:17:27pm', '0201', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (454, 3, '13/12/2017  05:17:19pm', '0193', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (453, 3, '13/12/2017  05:17:11pm', '0185', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (452, 3, '13/12/2017  05:17:03pm', '0177', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (451, 3, '13/12/2017  05:16:55pm', '0169', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (450, 3, '13/12/2017  05:16:47pm', '0161', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (449, 3, '13/12/2017  05:16:39pm', '0152', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (448, 3, '13/12/2017  05:16:31pm', '0144', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (447, 3, '13/12/2017  05:16:23pm', '0136', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (446, 3, '13/12/2017  05:16:15pm', '0128', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (445, 3, '13/12/2017  05:16:07pm', '0120', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (444, 3, '13/12/2017  05:15:59pm', '0112', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (443, 3, '13/12/2017  05:15:51pm', '0104', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (442, 3, '13/12/2017  05:15:43pm', '0096', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (441, 3, '13/12/2017  05:15:35pm', '0088', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (440, 3, '13/12/2017  05:15:27pm', '0080', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (439, 3, '13/12/2017  05:15:19pm', '0072', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (438, 3, '13/12/2017  05:15:11pm', '0064', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (437, 3, '13/12/2017  05:15:03pm', '0056', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (436, 3, '13/12/2017  05:14:55pm', '0048', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (435, 3, '13/12/2017  05:14:47pm', '0040', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (434, 3, '13/12/2017  05:14:39pm', '0032', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (433, 3, '13/12/2017  05:14:31pm', '0024', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (432, 3, '13/12/2017  05:14:23pm', '0016', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (431, 3, '13/12/2017  05:14:15pm', '0008', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (430, 3, '13/12/2017  05:14:07pm', '0001', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.38', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (429, 3, '13/12/2017  05:13:59pm', '1199', '0056', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (428, 3, '13/12/2017  05:13:51pm', '1199', '0048', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (427, 3, '13/12/2017  05:13:43pm', '1199', '0040', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (426, 3, '13/12/2017  05:13:35pm', '1199', '0032', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (425, 3, '13/12/2017  05:13:27pm', '1199', '0024', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (424, 3, '13/12/2017  05:13:19pm', '1199', '0016', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (423, 3, '13/12/2017  05:13:10pm', '1199', '0007', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (422, 3, '13/12/2017  05:13:02pm', '1198', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (421, 3, '13/12/2017  05:12:54pm', '1190', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (420, 3, '13/12/2017  05:12:47pm', '1182', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (419, 3, '13/12/2017  05:12:39pm', '1174', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (418, 3, '13/12/2017  05:12:31pm', '1166', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (417, 3, '13/12/2017  05:12:23pm', '1158', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (416, 3, '13/12/2017  05:12:15pm', '1150', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (415, 3, '13/12/2017  05:12:07pm', '1142', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (414, 3, '13/12/2017  05:11:59pm', '1134', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (413, 3, '13/12/2017  05:11:51pm', '1126', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (412, 3, '13/12/2017  05:11:43pm', '1118', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (411, 3, '13/12/2017  05:11:35pm', '1110', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (410, 3, '13/12/2017  05:11:27pm', '1102', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (409, 3, '13/12/2017  05:11:19pm', '1094', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (408, 3, '13/12/2017  05:11:11pm', '1086', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (407, 3, '13/12/2017  05:11:03pm', '1078', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (406, 3, '13/12/2017  05:10:55pm', '1070', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (405, 3, '13/12/2017  05:10:46pm', '1062', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (404, 3, '13/12/2017  05:10:38pm', '1054', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (403, 3, '13/12/2017  05:10:30pm', '1046', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (402, 3, '13/12/2017  05:10:22pm', '1038', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (401, 3, '13/12/2017  05:10:15pm', '1030', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (400, 3, '13/12/2017  05:10:07pm', '1022', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (399, 3, '13/12/2017  05:09:59pm', '1014', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (398, 3, '13/12/2017  05:09:51pm', '1006', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (397, 3, '13/12/2017  05:09:43pm', '0998', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (396, 3, '13/12/2017  05:09:35pm', '0990', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (395, 3, '13/12/2017  05:09:27pm', '0982', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (394, 3, '13/12/2017  05:09:19pm', '0974', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (393, 3, '13/12/2017  05:09:11pm', '0966', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (392, 3, '13/12/2017  05:09:03pm', '0958', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (391, 3, '13/12/2017  05:08:55pm', '0950', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (390, 3, '13/12/2017  05:08:47pm', '0942', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (389, 3, '13/12/2017  05:08:39pm', '0934', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (388, 3, '13/12/2017  05:08:31pm', '0926', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (387, 3, '13/12/2017  05:08:23pm', '0918', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (386, 3, '13/12/2017  05:08:15pm', '0910', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (385, 3, '13/12/2017  05:08:07pm', '0902', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (384, 3, '13/12/2017  05:07:59pm', '0894', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (383, 3, '13/12/2017  05:07:51pm', '0886', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (382, 3, '13/12/2017  05:07:43pm', '0878', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (381, 3, '13/12/2017  05:07:35pm', '0870', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (380, 3, '13/12/2017  05:07:27pm', '0862', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (379, 3, '13/12/2017  05:07:19pm', '0854', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (378, 3, '13/12/2017  05:07:11pm', '0846', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (377, 3, '13/12/2017  05:07:03pm', '0838', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (376, 3, '13/12/2017  05:06:55pm', '0830', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (375, 3, '13/12/2017  05:06:47pm', '0822', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (374, 3, '13/12/2017  05:06:39pm', '0814', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (373, 3, '13/12/2017  05:06:31pm', '0806', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (372, 3, '13/12/2017  05:06:23pm', '0798', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (371, 3, '13/12/2017  05:06:15pm', '0790', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (370, 3, '13/12/2017  05:06:07pm', '0782', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (369, 3, '13/12/2017  05:05:59pm', '0774', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (368, 3, '13/12/2017  05:05:52pm', '0767', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (367, 3, '13/12/2017  05:05:44pm', '0759', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (366, 3, '13/12/2017  05:05:36pm', '0751', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (365, 3, '13/12/2017  05:05:28pm', '0742', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (364, 3, '13/12/2017  05:05:19pm', '0734', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (363, 3, '13/12/2017  05:05:11pm', '0726', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (362, 3, '13/12/2017  05:05:03pm', '0718', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (361, 3, '13/12/2017  05:04:55pm', '0710', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (360, 3, '13/12/2017  05:04:47pm', '0702', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (359, 3, '13/12/2017  05:04:39pm', '0694', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (358, 3, '13/12/2017  05:04:31pm', '0686', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (357, 3, '13/12/2017  05:04:23pm', '0678', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (356, 3, '13/12/2017  05:04:15pm', '0670', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (355, 3, '13/12/2017  05:04:07pm', '0662', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (354, 3, '13/12/2017  05:03:59pm', '0654', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (353, 3, '13/12/2017  05:03:51pm', '0646', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (352, 3, '13/12/2017  05:03:43pm', '0638', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (351, 3, '13/12/2017  05:03:35pm', '0630', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (350, 3, '13/12/2017  05:03:27pm', '0622', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (349, 3, '13/12/2017  05:03:18pm', '0613', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (348, 3, '13/12/2017  05:03:10pm', '0605', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (347, 3, '13/12/2017  05:03:02pm', '0597', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (346, 3, '13/12/2017  05:02:54pm', '0589', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (345, 3, '13/12/2017  05:02:46pm', '0581', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (344, 3, '13/12/2017  05:02:38pm', '0573', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (343, 3, '13/12/2017  05:02:30pm', '0565', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (342, 3, '13/12/2017  05:02:22pm', '0557', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (341, 3, '13/12/2017  05:02:15pm', '0549', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (340, 3, '13/12/2017  05:02:05pm', '0539', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (339, 3, '13/12/2017  05:01:57pm', '0531', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (338, 3, '13/12/2017  05:01:49pm', '0523', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (337, 3, '13/12/2017  05:01:40pm', '0515', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (336, 3, '13/12/2017  05:01:32pm', '0507', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (335, 3, '13/12/2017  05:01:24pm', '0499', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (334, 3, '13/12/2017  05:01:16pm', '0491', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (333, 3, '13/12/2017  05:01:08pm', '0483', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (332, 3, '13/12/2017  05:01:00pm', '0475', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (331, 3, '13/12/2017  05:00:52pm', '0467', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (330, 3, '13/12/2017  05:00:44pm', '0459', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (329, 3, '13/12/2017  05:00:36pm', '0451', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (328, 3, '13/12/2017  05:00:28pm', '0443', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (327, 3, '13/12/2017  05:00:20pm', '0435', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (326, 3, '13/12/2017  05:00:12pm', '0427', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (325, 3, '13/12/2017  05:00:04pm', '0419', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (324, 3, '13/12/2017  04:59:56pm', '0411', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (323, 3, '13/12/2017  04:59:48pm', '0403', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (322, 3, '13/12/2017  04:59:40pm', '0395', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (321, 3, '13/12/2017  04:59:32pm', '0387', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (320, 3, '13/12/2017  04:59:24pm', '0379', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (319, 3, '13/12/2017  04:59:16pm', '0371', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (318, 3, '13/12/2017  04:59:08pm', '0363', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (317, 3, '13/12/2017  04:59:00pm', '0355', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (316, 3, '13/12/2017  04:58:52pm', '0347', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (315, 3, '13/12/2017  04:58:44pm', '0339', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (314, 3, '13/12/2017  04:58:36pm', '0331', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (313, 3, '13/12/2017  04:58:28pm', '0323', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (312, 3, '13/12/2017  04:58:20pm', '0315', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (311, 3, '13/12/2017  04:58:12pm', '0307', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (310, 3, '13/12/2017  04:58:04pm', '0299', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (309, 3, '13/12/2017  04:57:56pm', '0291', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (308, 3, '13/12/2017  04:57:48pm', '0283', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (307, 3, '13/12/2017  04:57:40pm', '0275', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (306, 3, '13/12/2017  04:57:32pm', '0267', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (305, 3, '13/12/2017  04:57:24pm', '0259', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (304, 3, '13/12/2017  04:57:16pm', '0251', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (303, 3, '13/12/2017  04:57:08pm', '0243', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (302, 3, '13/12/2017  04:57:00pm', '0235', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (301, 3, '13/12/2017  04:56:52pm', '0227', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (300, 3, '13/12/2017  04:56:44pm', '0219', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (299, 3, '13/12/2017  04:56:36pm', '0211', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (298, 3, '13/12/2017  04:56:28pm', '0203', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (297, 3, '13/12/2017  04:56:20pm', '0195', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (296, 3, '13/12/2017  04:56:12pm', '0187', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (295, 3, '13/12/2017  04:56:04pm', '0179', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (294, 3, '13/12/2017  04:55:56pm', '0171', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (293, 3, '13/12/2017  04:55:48pm', '0163', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (292, 3, '13/12/2017  04:55:40pm', '0155', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (291, 3, '13/12/2017  04:55:33pm', '0147', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (290, 3, '13/12/2017  04:55:24pm', '0139', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (289, 3, '13/12/2017  04:55:16pm', '0131', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (288, 3, '13/12/2017  04:55:08pm', '0123', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (287, 3, '13/12/2017  04:55:00pm', '0115', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (286, 3, '13/12/2017  04:54:52pm', '0107', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (285, 3, '13/12/2017  04:54:44pm', '0099', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (284, 3, '13/12/2017  04:54:36pm', '0091', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (283, 3, '13/12/2017  04:54:28pm', '0083', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (282, 3, '13/12/2017  04:54:20pm', '0075', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (281, 3, '13/12/2017  04:54:12pm', '0067', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (280, 3, '13/12/2017  04:54:04pm', '0059', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (279, 3, '13/12/2017  04:53:56pm', '0051', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (278, 3, '13/12/2017  04:53:48pm', '0043', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (277, 3, '13/12/2017  04:53:40pm', '0035', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (276, 3, '13/12/2017  04:53:32pm', '0027', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (275, 3, '13/12/2017  04:53:24pm', '0019', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.01', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (274, 3, '13/12/2017  04:53:16pm', '0011', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.01', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (273, 3, '13/12/2017  04:53:08pm', '0002', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.10', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (272, 3, '13/12/2017  04:53:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.01', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (271, 3, '13/12/2017  04:52:50pm', '0025', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (270, 3, '13/12/2017  04:52:40pm', '0015', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (269, 3, '13/12/2017  04:52:32pm', '0007', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (268, 3, '13/12/2017  04:52:24pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (267, 3, '13/12/2017  04:52:15pm', '0454', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (266, 3, '13/12/2017  04:52:06pm', '0445', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (265, 3, '13/12/2017  04:51:57pm', '0436', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (264, 3, '13/12/2017  04:51:48pm', '0427', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (263, 3, '13/12/2017  04:51:37pm', '0416', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (262, 3, '13/12/2017  04:51:29pm', '0408', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (261, 3, '13/12/2017  04:51:21pm', '0400', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (260, 3, '13/12/2017  04:51:12pm', '0392', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (259, 3, '13/12/2017  04:51:05pm', '0384', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (258, 3, '13/12/2017  04:38:12pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (257, 3, '13/12/2017  04:38:04pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (256, 3, '13/12/2017  04:37:55pm', '0259', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.04', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (255, 3, '13/12/2017  04:37:47pm', '0250', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.04', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (254, 3, '13/12/2017  04:37:39pm', '0242', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.04', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (253, 3, '13/12/2017  04:37:31pm', '0234', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (252, 3, '13/12/2017  04:37:23pm', '0226', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (251, 3, '13/12/2017  04:37:14pm', '0218', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (250, 3, '13/12/2017  04:37:06pm', '0210', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (249, 3, '13/12/2017  04:36:58pm', '0202', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (248, 3, '13/12/2017  04:36:50pm', '0194', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.06', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (247, 3, '13/12/2017  04:36:42pm', '0186', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (246, 3, '13/12/2017  04:36:34pm', '0178', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.06', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (245, 3, '13/12/2017  04:36:26pm', '0170', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.07', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (244, 3, '13/12/2017  04:36:18pm', '0162', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.07', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (243, 3, '13/12/2017  04:36:10pm', '0154', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.08', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (242, 3, '13/12/2017  04:36:02pm', '0146', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.08', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (241, 3, '13/12/2017  04:35:55pm', '0138', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.09', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (240, 3, '13/12/2017  04:35:46pm', '0130', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.09', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (239, 3, '13/12/2017  04:35:38pm', '0122', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.10', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (238, 3, '13/12/2017  04:35:30pm', '0114', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.11', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (237, 3, '13/12/2017  04:35:22pm', '0106', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.11', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (236, 3, '13/12/2017  04:35:14pm', '0098', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.12', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (235, 3, '13/12/2017  04:35:06pm', '0090', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.12', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (234, 3, '13/12/2017  04:34:58pm', '0082', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.13', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (233, 3, '13/12/2017  04:34:51pm', '0074', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.14', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (232, 3, '13/12/2017  04:34:42pm', '0066', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.16', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (231, 3, '13/12/2017  04:34:35pm', '0058', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.17', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (230, 3, '13/12/2017  04:34:27pm', '0050', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.19', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (229, 3, '13/12/2017  04:34:19pm', '0042', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.21', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (228, 3, '13/12/2017  04:34:11pm', '0034', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.22', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (227, 3, '13/12/2017  04:34:03pm', '0026', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.24', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (226, 3, '13/12/2017  04:33:55pm', '0018', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.27', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (225, 3, '13/12/2017  04:33:47pm', '0010', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.30', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (224, 3, '13/12/2017  04:33:39pm', '0002', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.52', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (223, 3, '13/12/2017  04:33:21pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (222, 3, '13/12/2017  04:33:11pm', '0043', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.28', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (221, 3, '13/12/2017  04:33:03pm', '0035', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.31', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (220, 3, '13/12/2017  04:32:55pm', '0027', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.34', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (219, 3, '13/12/2017  04:32:47pm', '0019', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.38', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (218, 3, '13/12/2017  04:32:39pm', '0011', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.42', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (217, 3, '13/12/2017  04:32:31pm', '0003', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.75', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (216, 3, '13/12/2017  04:32:23pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (215, 3, '13/12/2017  04:32:15pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (214, 3, '13/12/2017  04:32:07pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (213, 3, '13/12/2017  04:31:59pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (212, 3, '13/12/2017  04:31:51pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (211, 3, '13/12/2017  04:31:43pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (210, 3, '13/12/2017  04:31:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (209, 3, '13/12/2017  04:31:27pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (208, 3, '13/12/2017  04:31:19pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.35', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (207, 3, '13/12/2017  04:31:11pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.39', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (206, 3, '13/12/2017  04:31:03pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.43', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (205, 3, '13/12/2017  04:30:55pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.49', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (204, 3, '13/12/2017  04:30:47pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.71', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (203, 3, '13/12/2017  04:30:39pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (202, 3, '13/12/2017  04:30:31pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (201, 3, '13/12/2017  04:30:23pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (200, 3, '13/12/2017  04:30:16pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (199, 3, '13/12/2017  04:30:08pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (198, 3, '13/12/2017  04:30:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (197, 3, '13/12/2017  04:29:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (196, 3, '13/12/2017  04:29:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (195, 3, '13/12/2017  04:29:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (194, 3, '13/12/2017  04:29:28pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (193, 3, '13/12/2017  04:29:18pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.51', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (192, 3, '13/12/2017  04:29:10pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.64', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (191, 3, '13/12/2017  04:29:02pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (190, 3, '13/12/2017  04:28:54pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (189, 3, '13/12/2017  04:28:46pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (188, 3, '13/12/2017  04:28:38pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (187, 3, '13/12/2017  04:28:30pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (186, 3, '13/12/2017  04:28:21pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (185, 3, '13/12/2017  04:28:13pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (184, 3, '13/12/2017  04:28:06pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (183, 3, '13/12/2017  04:27:58pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (182, 3, '13/12/2017  04:27:49pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (181, 3, '13/12/2017  04:27:41pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (180, 3, '13/12/2017  04:27:33pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (179, 3, '13/12/2017  04:27:25pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (178, 3, '13/12/2017  04:27:16pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (177, 3, '13/12/2017  04:27:08pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (176, 3, '13/12/2017  04:27:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (175, 3, '13/12/2017  04:26:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (174, 3, '13/12/2017  04:26:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (173, 3, '13/12/2017  04:26:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (172, 3, '13/12/2017  04:26:28pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (171, 3, '13/12/2017  04:26:20pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (170, 3, '13/12/2017  04:26:12pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (169, 3, '13/12/2017  04:26:04pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (168, 3, '13/12/2017  04:25:56pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (167, 3, '13/12/2017  04:25:47pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (166, 3, '13/12/2017  04:25:39pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (165, 3, '13/12/2017  04:25:31pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (164, 3, '13/12/2017  04:25:24pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (163, 3, '13/12/2017  04:25:16pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (162, 3, '13/12/2017  04:25:08pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (161, 3, '13/12/2017  04:25:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (160, 3, '13/12/2017  04:24:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (159, 3, '13/12/2017  04:24:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (158, 3, '13/12/2017  04:24:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (157, 3, '13/12/2017  04:24:28pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (156, 3, '13/12/2017  04:24:20pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (155, 3, '13/12/2017  04:24:11pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (154, 3, '13/12/2017  04:24:03pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (153, 3, '13/12/2017  04:23:54pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (152, 3, '13/12/2017  04:23:46pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (151, 3, '13/12/2017  04:23:38pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (150, 3, '13/12/2017  04:23:29pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (149, 3, '13/12/2017  04:23:21pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (148, 3, '13/12/2017  04:23:12pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (147, 3, '13/12/2017  04:23:04pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (146, 3, '13/12/2017  04:22:56pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (145, 3, '13/12/2017  04:22:48pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (144, 3, '13/12/2017  04:22:40pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (143, 3, '13/12/2017  04:22:32pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (142, 3, '13/12/2017  04:22:24pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (141, 3, '13/12/2017  04:22:16pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (140, 3, '13/12/2017  04:22:08pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (139, 3, '13/12/2017  04:22:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (138, 3, '13/12/2017  04:21:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (137, 3, '13/12/2017  04:21:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (136, 3, '13/12/2017  04:21:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (135, 3, '13/12/2017  04:21:28pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (134, 3, '13/12/2017  04:21:20pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (133, 3, '13/12/2017  04:21:12pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (132, 3, '13/12/2017  04:21:04pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (131, 3, '13/12/2017  04:20:56pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (130, 3, '13/12/2017  04:20:48pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (129, 3, '13/12/2017  04:20:40pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (128, 3, '13/12/2017  04:20:32pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (127, 3, '13/12/2017  04:20:25pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (126, 3, '13/12/2017  04:20:17pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (125, 3, '13/12/2017  04:20:09pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (124, 3, '13/12/2017  04:20:01pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (123, 3, '13/12/2017  04:19:53pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (122, 3, '13/12/2017  04:19:45pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (121, 3, '13/12/2017  04:19:37pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (120, 3, '13/12/2017  04:19:29pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (119, 3, '13/12/2017  04:19:21pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (118, 3, '13/12/2017  04:19:13pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (117, 3, '13/12/2017  04:19:05pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (116, 3, '13/12/2017  04:18:57pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (115, 3, '13/12/2017  04:18:49pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (114, 3, '13/12/2017  04:18:41pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (113, 3, '13/12/2017  04:18:33pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (112, 3, '13/12/2017  04:18:25pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (111, 3, '13/12/2017  04:18:17pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (110, 3, '13/12/2017  04:18:09pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (109, 3, '13/12/2017  04:18:01pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (108, 3, '13/12/2017  04:17:53pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (107, 3, '13/12/2017  04:17:45pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (106, 3, '13/12/2017  04:17:37pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (105, 3, '13/12/2017  04:17:29pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (104, 3, '13/12/2017  04:17:21pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (103, 3, '13/12/2017  04:17:14pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (102, 3, '13/12/2017  04:17:06pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (101, 3, '13/12/2017  04:16:58pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (100, 3, '13/12/2017  04:16:48pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (99, 3, '13/12/2017  04:16:40pm', '0535', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (98, 3, '13/12/2017  04:16:32pm', '0527', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (97, 3, '13/12/2017  04:16:24pm', '0519', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (96, 3, '13/12/2017  04:16:16pm', '0511', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (95, 3, '13/12/2017  04:16:08pm', '0503', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (94, 3, '13/12/2017  04:16:00pm', '0495', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (93, 3, '13/12/2017  04:15:52pm', '0487', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (92, 3, '13/12/2017  04:15:44pm', '0479', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (91, 3, '13/12/2017  04:15:36pm', '0471', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (90, 3, '13/12/2017  04:15:28pm', '0463', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (89, 3, '13/12/2017  04:15:20pm', '0455', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (88, 3, '13/12/2017  04:15:12pm', '0447', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (87, 3, '13/12/2017  04:15:04pm', '0439', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.95', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (86, 3, '13/12/2017  04:14:56pm', '0431', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (85, 3, '13/12/2017  04:14:48pm', '0423', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (84, 3, '13/12/2017  04:14:40pm', '0415', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (83, 3, '13/12/2017  04:14:32pm', '0407', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (82, 3, '13/12/2017  04:14:24pm', '0399', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (81, 3, '13/12/2017  04:14:16pm', '0391', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (80, 3, '13/12/2017  04:14:08pm', '0383', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (79, 3, '13/12/2017  04:14:00pm', '0375', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.96', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (78, 3, '13/12/2017  04:13:52pm', '0367', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (77, 3, '13/12/2017  04:13:44pm', '0359', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.96', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (76, 3, '13/12/2017  04:13:36pm', '0351', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (75, 3, '13/12/2017  04:13:28pm', '0343', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (74, 3, '13/12/2017  04:13:20pm', '0335', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (73, 3, '13/12/2017  04:13:12pm', '0327', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (72, 3, '13/12/2017  04:13:04pm', '0319', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (71, 3, '13/12/2017  04:12:56pm', '0311', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (70, 3, '13/12/2017  04:12:48pm', '0303', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.97', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (69, 3, '13/12/2017  04:12:40pm', '0295', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.97', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (68, 3, '13/12/2017  04:12:32pm', '0287', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (67, 3, '13/12/2017  04:12:24pm', '0279', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (66, 3, '13/12/2017  04:12:16pm', '0271', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (65, 3, '13/12/2017  04:12:08pm', '0263', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (64, 3, '13/12/2017  04:12:00pm', '0255', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (63, 3, '13/12/2017  04:11:52pm', '0247', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (62, 3, '13/12/2017  04:11:44pm', '0239', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (61, 3, '13/12/2017  04:11:36pm', '0231', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (60, 3, '13/12/2017  04:11:28pm', '0223', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (59, 3, '13/12/2017  04:11:20pm', '0215', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.98', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (58, 3, '13/12/2017  04:11:12pm', '0207', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (57, 3, '13/12/2017  04:11:04pm', '0199', '0000', '0000', '0000', '000.01', '000.01', '000.01', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (56, 3, '13/12/2017  04:10:56pm', '0190', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (55, 3, '13/12/2017  04:10:48pm', '0182', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (54, 3, '13/12/2017  04:10:40pm', '0174', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.00', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (53, 3, '13/12/2017  04:10:32pm', '0166', '0000', '0000', '0000', '000.01', '000.01', '000.00', '004.99', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (52, 3, '13/12/2017  04:10:24pm', '0158', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.00', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (51, 3, '13/12/2017  04:10:16pm', '0150', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.01', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (50, 3, '13/12/2017  04:10:08pm', '0142', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.01', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (49, 3, '13/12/2017  04:10:00pm', '0134', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.02', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (48, 3, '13/12/2017  04:09:52pm', '0126', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.01', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (47, 3, '13/12/2017  04:09:44pm', '0118', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.02', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (46, 3, '13/12/2017  04:09:36pm', '0110', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.02', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (45, 3, '13/12/2017  04:09:28pm', '0102', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.02', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (44, 3, '13/12/2017  04:09:20pm', '0094', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.03', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (43, 3, '13/12/2017  04:09:12pm', '0086', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.03', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (42, 3, '13/12/2017  04:09:04pm', '0078', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.04', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (41, 3, '13/12/2017  04:08:55pm', '0070', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.04', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (40, 3, '13/12/2017  04:08:47pm', '0062', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (39, 3, '13/12/2017  04:08:40pm', '0054', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.05', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (38, 3, '13/12/2017  04:08:31pm', '0046', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.06', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (37, 3, '13/12/2017  04:08:23pm', '0038', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.07', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (36, 3, '13/12/2017  04:08:15pm', '0030', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.08', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (35, 3, '13/12/2017  04:08:07pm', '0022', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.09', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (34, 3, '13/12/2017  04:08:00pm', '0014', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.10', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (33, 3, '13/12/2017  04:07:52pm', '0006', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.11', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (32, 3, '13/12/2017  04:07:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.01', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (31, 3, '13/12/2017  04:07:36pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.12', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (30, 3, '13/12/2017  04:07:28pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.13', '000.01', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (29, 3, '13/12/2017  04:07:19pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.14', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (28, 3, '13/12/2017  04:07:11pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.16', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (27, 3, '13/12/2017  04:07:03pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.18', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (26, 3, '13/12/2017  04:06:55pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.20', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (25, 3, '13/12/2017  04:06:47pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.22', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (24, 3, '13/12/2017  04:06:39pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.25', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (23, 3, '13/12/2017  04:06:31pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.28', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (22, 3, '13/12/2017  04:06:23pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.32', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (21, 3, '13/12/2017  04:06:15pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.36', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (20, 3, '13/12/2017  04:06:07pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.00', '005.40', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (19, 3, '13/12/2017  04:05:59pm', '0000', '0000', '0000', '0000', '000.01', '000.01', '000.01', '005.47', '000.02', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (18, 3, '13/12/2017  04:05:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (17, 3, '13/12/2017  04:05:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (16, 3, '13/12/2017  04:05:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (15, 3, '13/12/2017  04:05:28pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (14, 3, '13/12/2017  04:05:20pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (13, 3, '13/12/2017  04:05:12pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (12, 3, '13/12/2017  04:05:04pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (11, 3, '13/12/2017  04:04:56pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (10, 3, '13/12/2017  04:04:47pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (9, 3, '13/12/2017  04:04:39pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (8, 3, '13/12/2017  04:04:31pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (7, 3, '13/12/2017  04:04:23pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (6, 3, '13/12/2017  04:04:15pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (5, 3, '13/12/2017  04:04:08pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (4, 3, '13/12/2017  04:04:00pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (3, 3, '13/12/2017  04:03:52pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (2, 3, '13/12/2017  04:03:44pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');
INSERT INTO `tb_web_monitor_b` VALUES (1, 3, '13/12/2017  04:03:36pm', '0000', '0000', '0000', '0000', '000.00', '000.00', '000.00', '000.00', '000.00', '000.00');

-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tb_web_monitor_c`
-- 

CREATE TABLE `tb_web_monitor_c` (
  `id` int(10) NOT NULL auto_increment,
  `id_user` int(10) NOT NULL,
  `date_log` text NOT NULL,
  `alram1` varchar(10) NOT NULL,
  `alram2` varchar(10) NOT NULL,
  `alram3` varchar(10) NOT NULL,
  PRIMARY KEY  (`id`)
) ENGINE=MyISAM  DEFAULT CHARSET=utf8 AUTO_INCREMENT=5 ;

-- 
-- dump ตาราง `tb_web_monitor_c`
-- 


-- --------------------------------------------------------

-- 
-- โครงสร้างตาราง `tx_monitor_c`
-- 

CREATE TABLE `tx_monitor_c` (
  `id_user` int(10) NOT NULL,
  `tx_in1` text NOT NULL,
  `tx_in2` text NOT NULL,
  `tx_in3` text NOT NULL,
  `tx_out1` text NOT NULL,
  `tx_out2` text NOT NULL,
  `tx_out3` text NOT NULL,
  `tx_am1` text NOT NULL,
  `tx_am2` text NOT NULL,
  `tx_am3` text NOT NULL,
  PRIMARY KEY  (`id_user`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8;

-- 
-- dump ตาราง `tx_monitor_c`
-- 

INSERT INTO `tx_monitor_c` VALUES (1, 'TAS', 'AAAAAAAAAA', 'dddd', 'iiii', 'yuuuu', 'uuu', '222', '333', '44');
